# Info:

Workaround for updating offline images of Windows 10 build 10240 x86  
by fixing SSShim.dll error

## Prerequisite:

Wim file(s) must be vanilla (RTM) images, without any integrated updates

## How to:

- Updating WIM files:  
place wim file next to FixSSShim10240x86.cmd  
or enter/paste wim file path in the prompt  
run FixSSShim10240x86.cmd as administrator  
you may repeat the process to fix both boot.wim/install.wim  
afterwards, you can use W10UI.cmd or other tools to update wim files

- Updating mounted directory:  
manually mount wim image (either install.wim, boot.wim or winre.wim)  
run FixSSShim10240x86.cmd as administrator  
enter/paste mount directory path in the prompt  
you may then proceed to integrate SSU and LCU updates  
manually unmount/commit wim image

- Note:  
if you are updating wim files and do not want to fix winre.wim inside install.wim  
edit FixSSShim10240x86.cmd and set FixWinre=0
