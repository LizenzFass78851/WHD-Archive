===============================================================================
Info:

Data Deduplication pack version 10.0.10586.0 (Windows Server 2016 Technical Preview 4)
for Windows 10 (10.10240.16384)

===============================================================================
Preparations:

- After you download the pack, make sure the .7z file is Unblocked
to do so, right click on file, check properties general - click Unblock button if present

- Extract the package to a directory with simple short path without spaces (example: C:\Dedup)

===============================================================================
Instructions:

1)
Run _TestRights.cmd script as administrator
if another command prompt window is opened, then close it and proceed to step 2)
if no cmd window opened, try again one or two more times
if still no cmd windows opened, then you need to reboot the system and test again.

2)
Run the outer Installer.cmd script as administrator to install the pack

===============================================================================
Credits:

http://forums.mydigitallife.info/members/204274-abbodi1406
http://forums.mydigitallife.info/members/221250-100
http://forums.mydigitallife.info/members/250156-SuperBubble
http://forums.mydigitallife.info/members/88944-moderate
http://forums.mydigitallife.info/members/80800-SLRVision39
