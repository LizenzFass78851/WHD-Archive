===============================================================================
# Info #

A set of CBS packages which form "KB3161647 Windows Update Client" update for Windows 7 SP1 and Windows Server 2008 R2 SP1
this update provide latest improvements and fixes to Windows Update, specially:
An optimization that addresses long scan time for updates.

these packages are originally sub-packages and part of "July 2016 update rollup KB3172605"
they only contain Windows Update components that are included in the rollup.

note: Windows Embedded 7 is not supported by this project.

===============================================================================
# Advantages #

- allows you to have the WU fix solely without other fixes in the rollup that you may not want or cause you problems
- do not need any prerequisites updates (the whole rollup require servicing stack update KB3020369)
- installation is done normally with DISM tool like any other updates packages
- completely safe, all files are in their original state, the project is just a repacking of files
and the system itself checks files integrity and won't allow the installation if the check failed

===============================================================================
# Disadvantages #

as a side effect you will get multiple enries for KB3172605 in "Installed Updates" panel
and if you decided to install the whole KB3172605 rollup later, you will also get one more entry

this is merely a cosmetic issue that don't decrease or affect the packages functionality

===============================================================================
# How To Use #

- Make sure the downloaded zip file is not read-only or blocked
extract the file to a folder with a simple spaceless path to avoid troubles

- for online installation on live running system, run install-online.cmd as administrator
you will be notified to restart the system to complete installation if succeded

- for offline integration into image:
1) Mount the image of install.wim
no need for this step if the target image is already deployed on another partition/drive

2) run integrate-offline.cmd as administrator and enter the correct path for mounted/deployed image

- note:
if you choose to install the packages yourself on live rinning system, make sure to add the correct LangPack package first, before the main package

===============================================================================